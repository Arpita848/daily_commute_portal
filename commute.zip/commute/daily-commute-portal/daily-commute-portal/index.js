const express = require('express');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON
app.use(express.json());

// Serve static files (like index.html)
app.use(express.static(path.join(__dirname, 'public')));

// Route for homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route for route planning
app.post('/api/route', async (req, res) => {
    const { origin, destination } = req.body;

    if (!origin || !destination) {
        return res.status(400).json({ error: 'Origin and destination are required.' });
    }

    const googleMapsURL = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&key=${process.env.GOOGLE_MAPS_API_KEY}`;

    try {
        const response = await fetch(googleMapsURL);
        const data = await response.json();

        if (data.status === 'OK') {
            res.json(data.routes[0].legs[0]);
        } else {
            res.status(400).json({ error: 'Route not found. Please try again.' });
        }
    } catch (error) {
        console.error('Error fetching route:', error);
        res.status(500).json({ error: 'Server error while fetching route.' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
